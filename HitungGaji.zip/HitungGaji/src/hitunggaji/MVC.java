package hitunggaji;


class MVC {
    public void Gaji_P(){
        VGaji_P vGaji_P = new VGaji_P();
        Model model = new Model();
        Controller controller = new Controller(vGaji_P, model);
    }
    
    public void Data_P(){
        VData_P vData_P = new VData_P();
        Model model = new Model();
        Controller controller = new Controller(vData_P,model);
    }

    void Home_A() {
        new VHome_A();
    }
    
    void Home_P() {
        new VHome_P();
    }

    void Data_A() {
        VData_A vData_A = new VData_A();
        Model model = new Model();
        Controller controller = new Controller(vData_A,model);
    }

    void Tambah_A() {
        new VTambah_A();
    }
    
}
